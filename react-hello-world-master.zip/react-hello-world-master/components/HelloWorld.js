import React from 'react';
class HelloWorld extends React.Component {
  render() {
    return (
      <div>
        <h1>Hello World</h1>
        <p>Welcome to my world dude</p>
      </div>
    );
  }
}
export default HelloWorld;
